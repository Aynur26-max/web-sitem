

console.log("Akustik web sitesi başarıyla yüklendi.");

